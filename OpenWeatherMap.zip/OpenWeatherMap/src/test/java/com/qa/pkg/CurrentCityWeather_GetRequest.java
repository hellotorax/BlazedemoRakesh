package com.qa.pkg;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import junit.framework.Assert;

public class CurrentCityWeather_GetRequest {
	
	private static String APIKEY = "cd1052608f9426cfd1579eab3b5f2dfb";
	private static String CITYNAME = "London";
	int  CITYID = 2172797;
			
	@SuppressWarnings("deprecation")
	@Test
	void getWeatherDetails() {
		//Specify the base URI
		RestAssured.baseURI="https://api.openweathermap.org/data/2.5";
		
		Response response = null;
		try {
			 response = RestAssured.given()
					.when().queryParam("q", CITYNAME).queryParam("appid", APIKEY)
					.get("/weather");
		} catch (Exception e) {
            e.printStackTrace();
        }
		
		String responseBody = response.getBody().asString();
		System.out.println("Response of the body is "+responseBody);
		//Status Code validation
		int statusCode = response.getStatusCode();
		System.out.println("Status code is :"+ statusCode);
		Assert.assertEquals(200, statusCode);
		
		//status line verification
		String statusLine=response.statusLine();
		System.out.println("Status Line is : " + statusLine);
		Assert.assertEquals("HTTP/1.1 200 OK", statusLine);
		
		//header validation
		String contentType=response.header("content-type");;
		Assert.assertEquals("application/json; charset=utf-8", contentType);
		System.out.println("content-type is : "+contentType);
		
		
	}
}
